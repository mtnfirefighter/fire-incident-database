# Fire Incident Reports — v4.3.2
- Remove personnel & apparatus rows via checkbox in editable grids
- Personnel gains **RespondedIn** column to mark which unit the member came on
- Apparatus UnitType picker includes **Mini Pumper** by default (plus your lookups)
- Apparatus rows have editable **Actions** (e.g., "Directing traffic")
- Add-members dialog supports default **Responded In**
